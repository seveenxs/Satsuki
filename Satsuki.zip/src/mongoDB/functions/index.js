const { LatencyDB } = require('./database');

module["exports"] = {
    LatencyDB
}