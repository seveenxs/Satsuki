const { FormatEmoji } = require('./FormatEmoji');
const { createProfile } = require('./CreateProfile');

module["exports"] = {
    FormatEmoji,
    createProfile
}